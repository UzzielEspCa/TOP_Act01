package com.example.topicos_act01;
/*
TÓPICOS AVANZADOS DE PROGRAMACIÓN - Actividad 01
Uzziel Espinoza Calles
* */
public class Saludo {
    public static void main(String[] args){
        System.out.println("Hola Mundo!");
    }
}
